To run:
cd into the directory containg CLIToolMain.py
input "python CLIToolMain.py TestFiles/filename.asm --cycles 10000" in the CLI
